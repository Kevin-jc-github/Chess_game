Team20: Chessnoob

Author: Kevin Zhu, Yuan Wang, Chenyu Mou, Tiantian Lu, Pengfei Yan

Alpha version of our chess game. Read install to install the game. Read doc//Chess_UserManual.pdf to see the instrctions.
