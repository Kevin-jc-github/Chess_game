#ifndef AI_H
#define AI_H

#include "Board.h"
#include "IO.h"
#include <stdio.h>
#include <stdlib.h>
#include "Pieces.h"

void AIMOVE(c_piece*board[8][8], int turn);


#endif /* AI_H */